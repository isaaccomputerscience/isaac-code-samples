# Stack

This repository contains code and pseudocode for a stack data structure

There are two sample implementations on the platform:

1. a stack built using a static array
2. a stack built using a (dynamic) linked list
